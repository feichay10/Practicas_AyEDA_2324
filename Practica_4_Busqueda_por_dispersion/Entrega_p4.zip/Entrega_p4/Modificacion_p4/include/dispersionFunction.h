/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Asignatura: Algoritmos y Estructura de Datos Avanzada
 * Curso: 2º
 * Práctica 4: Búsqueda por dispersión
 * @file dispersionFunction.h
 * @author Cheuk Kelly Ng Pante (alu0101364544@ull.edu.es)
 * @brief
 * @version 0.1
 * @date 2024-03-18
 *
 * @copyright Copyright (c) 2023
 *
 */

#ifndef DISPERSIONFUNCTION_H
#define DISPERSIONFUNCTION_H

#include "nif.h"

/**
 * @brief Abstract class that represents the dispersion function
 * 
 * @tparam Key 
 */
template <class Key>
class DispersionFunction {
 public:
  virtual unsigned operator()(const Key&) const = 0;
};

#endif  // DISPERSIONFUNCTION_H