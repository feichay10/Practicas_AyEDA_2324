/**
 *
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Asignatura: Algoritmos y Estructura de Datos Avanzada
 * Curso: 2º
 * Práctica 3: Autómata celular general
 * @file cell.h
 * @author Cheuk Kelly Ng Pante (alu0101364544@ull.edu.es)
 * @brief
 * @version 0.1
 * @date
 *
 * @copyright Copyright (c) 2024
 *
 */

#ifndef CELL_H
#define CELL_H

#include <iostream>

#include "lattice.h"
#include "position.h"
#include "state.h"

class Cell {
 public:
  // Cell(const State& state) : state_(state) {}
  Cell(const Position& position, const State& state) : position_(position), state_(state) {}

  State getState() const { return state_; }
  void setState(State state) { state_ = state; }

  virtual void nextState(const Lattice& lattice) = 0;
  virtual void updateState() { state_ = nextState_; }

  virtual std::ostream& display(std::ostream&) = 0;
  friend std::ostream& operator<<(std::ostream& os, Cell& cell) {
    return cell.display(os);
  }

 protected:
  State state_;
  State nextState_;
};

class CellACE : public Cell {
 public:
  CellACE(const Position& position, const State& state) : Cell(position, state) {}

  virtual void nextState(const Lattice1D& lattice) = 0;
  virtual std::ostream& display(std::ostream&) = 0;

 protected:
  PositionDim<1> position_;
};

class CellACE110 : public CellACE {
 public:
  CellACE110(const PositionDim<1>& position, const State& state) : CellACE(position, state) {}

  // Regla 110 -> C =(C + R + C * R + L * C * R) % 2
  void nextState(const Lattice1D& lattice) override {
    int left = lattice[position_[0] - 1].getState();
    int right = lattice[position_[0] + 1].getState();
    int center = lattice[position_[0]].getState();

    nextState_ = static_cast<State>((center + right + center * right + left * center * right) % 2);
  }

  std::ostream& display(std::ostream& os) const {
    os << state_;
    return os;
  }
};

#endif  // CELL_H